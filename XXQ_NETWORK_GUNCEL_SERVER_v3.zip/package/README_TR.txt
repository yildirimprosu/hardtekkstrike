HARDTEKK STRIKE - XXQ NETWORK

Guncellemeler:
- Bicaklarin hasari yukseltilerek 200 yapildi.
- Bicak saldirisinin menzili ve hedef yakalama toleransi artirildi.
- Bicak eldeyken hareket hizi belirgin sekilde artirildi.
- Ayri kosma tusu ve Shift ile kosma kaldirildi.
- Cevrimici hasar tablosu da guncellendi; sunucu tarafinda da bicak hasari uygulanir.

Calistirma:
1. Node.js kurulu olmali.
2. Terminalde bu klasore gir.
3. npm install
4. npm start
5. Tarayicida http://localhost:3000 ac.

Not: Bu paket kod duzeyinde kontrol edildi; farkli cihazlarda ve canli cok oyunculu ortamda tam oyun testi yapilmadi.
